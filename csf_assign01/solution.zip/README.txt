Names: Aya Habbas, Emily Berger

We pair coded the entire assignment, so work was split 50/50. 
