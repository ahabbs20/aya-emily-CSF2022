Partners:
Emily Berger - eberge11@jh.edu
Aya Habbas - ahabbas1@jh.edu

Contributions: 

Makefile and main function pair coded




